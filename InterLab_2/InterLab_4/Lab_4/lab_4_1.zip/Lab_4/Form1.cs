using System.Data;
using System.Windows.Forms;

namespace lab_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bAdd_Click(object sender, EventArgs e)
        {
            int n = dgvAdmin.Rows.Add();

            dgvAdmin.Rows[n].Cells["colManufacturer"].Value = tbManufacturer.Text;
            dgvAdmin.Rows[n].Cells["colBrand"].Value = tbBrand.Text;
            dgvAdmin.Rows[n].Cells["colOS"].Value = tbOS.Text;
            dgvAdmin.Rows[n].Cells["colLink"].Value = tbLink.Text;
            dgvAdmin.Rows[n].Cells["colPrice"].Value = tbPrice.Text;
            dgvAdmin.Rows[n].Cells["colYear"].Value = tbYear.Text;
        }

        private void bEdit_Click(object sender, EventArgs e)
        {
            dgvAdmin.SelectedRows[0].Cells["colManufacturer"].Value = tbManufacturer.Text;
            dgvAdmin.SelectedRows[0].Cells["colBrand"].Value = tbBrand.Text;
            dgvAdmin.SelectedRows[0].Cells["colOS"].Value = tbOS.Text;
            dgvAdmin.SelectedRows[0].Cells["colLink"].Value = tbLink.Text;
            dgvAdmin.SelectedRows[0].Cells["colPrice"].Value = tbPrice.Text;
            dgvAdmin.SelectedRows[0].Cells["colYear"].Value = tbYear.Text;
        }

        private void bDel_Click(object sender, EventArgs e)
        {
            if (dgvAdmin.SelectedRows.Count > 0)
            {
                dgvAdmin.Rows.Remove(dgvAdmin.SelectedRows[0]);
            }
        }

        private void bDow_Click(object sender, EventArgs e)
        {
            if (dgvAdmin.Rows.Count > 0)
            {
                MessageBox.Show("Clear table rows. Error.");
            }
            else
            {
                if (File.Exists("data.xml"))
                {
                    DataSet ds = new DataSet();
                    ds.ReadXml("data.xml");
                    foreach (DataRow r in ds.Tables["Admin"].Rows)
                    {
                        int n = dgvAdmin.Rows.Add();
                        dgvAdmin.Rows[n].Cells["colManufacturer"].Value = r["Manufacturer"];
                        dgvAdmin.Rows[n].Cells["colBrand"].Value = r["Brand"];
                        dgvAdmin.Rows[n].Cells["colOS"].Value = r["OS"];
                        dgvAdmin.Rows[n].Cells["colLink"].Value = r["Link"];
                        dgvAdmin.Rows[n].Cells["colPrice"].Value = r["Price"];
                        dgvAdmin.Rows[n].Cells["colYear"].Value = r["Year"];
                    }
                }
                else
                {
                    MessageBox.Show("Download error: 1::9");
                }
            }
        }

        private void bSet_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                dt.TableName = "Admin";
                dt.Columns.Add("Manufacturer");
                dt.Columns.Add("Brand");
                dt.Columns.Add("OS");
                dt.Columns.Add("Link");
                dt.Columns.Add("Price");
                dt.Columns.Add("Year");

                ds.Tables.Add(dt);

                foreach (DataGridViewRow r in dgvAdmin.Rows)
                {
                    DataRow row = ds.Tables["Admin"].NewRow();
                    row["Manufacturer"] = r.Cells["colManufacturer"].Value.ToString();
                    row["Brand"] = r.Cells["colBrand"].Value.ToString();
                    row["OS"] = r.Cells["colOS"].Value.ToString();
                    row["Link"] = r.Cells["colLink"].Value.ToString();
                    row["Price"] = r.Cells["colPrice"].Value.ToString();
                    row["Year"] = r.Cells["colYear"].Value.ToString();

                    ds.Tables["Admin"].Rows.Add(row);
                }
                ds.WriteXml("data.xml");
            }
            catch
            {
                MessageBox.Show("Save error: 1::7");
            }
        }

        private void bClear_Click(object sender, EventArgs e)
        {
            if (dgvAdmin.Rows.Count > 0)
            {
                dgvAdmin.Rows.Clear();
            }
        }

        private void bSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbYear.Text))
            {
                MessageBox.Show("Search parameter is empty!");
            }
            else
            {
                DataSet dss = new DataSet();
                DataTable dts = new DataTable();
                dts.TableName = "AdminSearch";
                dts.Columns.Add("�������������");
                dts.Columns.Add("�����");
                dts.Columns.Add("��");
                dts.Columns.Add("������");
                dts.Columns.Add("���������");
                dts.Columns.Add("��� ������");

                dss.Tables.Add(dts);

                foreach (DataGridViewRow r in dgvAdmin.Rows)
                {
                    if (r.Cells["colYear"].Value.ToString() == tbYear.Text)
                    {
                        DataRow row = dss.Tables["AdminSearch"].NewRow();
                        row["�������������"] = r.Cells["colManufacturer"].Value.ToString();
                        row["�����"] = r.Cells["colBrand"].Value.ToString();
                        row["��"] = r.Cells["colOS"].Value.ToString();
                        row["������"] = r.Cells["colLink"].Value.ToString();
                        row["���������"] = r.Cells["colPrice"].Value.ToString();
                        row["��� ������"] = r.Cells["colYear"].Value.ToString();

                        dss.Tables["AdminSearch"].Rows.Add(row);
                    }
                }

                if (dss.Tables["AdminSearch"].Rows.Count == 0)
                {
                    MessageBox.Show("Oops... It seems nothing was found.");
                }
                else
                {
                    Form2 fSearch = new Form2(dss, "AdminSearch");
                    fSearch.Show();
                }
            }
        }
    }
}