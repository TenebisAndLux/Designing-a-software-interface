﻿namespace lab_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dgvAdmin = new DataGridView();
            bDow = new Button();
            bSet = new Button();
            bClear = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            tbManufacturer = new TextBox();
            tbBrand = new TextBox();
            tbOS = new TextBox();
            tbLink = new TextBox();
            tbPrice = new TextBox();
            tbYear = new TextBox();
            bAdd = new Button();
            bEdit = new Button();
            bDel = new Button();
            panel1 = new Panel();
            bSearch = new Button();
            panel2 = new Panel();
            colManufacturer = new DataGridViewTextBoxColumn();
            colBrand = new DataGridViewTextBoxColumn();
            colOS = new DataGridViewTextBoxColumn();
            colLink = new DataGridViewTextBoxColumn();
            colPrice = new DataGridViewTextBoxColumn();
            colYear = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvAdmin).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // dgvAdmin
            // 
            dgvAdmin.AllowUserToAddRows = false;
            dgvAdmin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAdmin.Columns.AddRange(new DataGridViewColumn[] { colManufacturer, colBrand, colOS, colLink, colPrice, colYear });
            dgvAdmin.Location = new Point(320, 12);
            dgvAdmin.MultiSelect = false;
            dgvAdmin.Name = "dgvAdmin";
            dgvAdmin.RowTemplate.Height = 23;
            dgvAdmin.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAdmin.Size = new Size(734, 426);
            dgvAdmin.TabIndex = 0;
            // 
            // bDow
            // 
            bDow.Location = new Point(3, 12);
            bDow.Name = "bDow";
            bDow.Size = new Size(210, 40);
            bDow.TabIndex = 1;
            bDow.Text = "Загрузить XML";
            bDow.UseVisualStyleBackColor = true;
            bDow.Click += bDow_Click;
            // 
            // bSet
            // 
            bSet.Location = new Point(266, 12);
            bSet.Name = "bSet";
            bSet.Size = new Size(210, 40);
            bSet.TabIndex = 2;
            bSet.Text = "Выгрузить XML";
            bSet.UseVisualStyleBackColor = true;
            bSet.Click += bSet_Click;
            // 
            // bClear
            // 
            bClear.Location = new Point(521, 12);
            bClear.Name = "bClear";
            bClear.Size = new Size(210, 40);
            bClear.TabIndex = 3;
            bClear.Text = "Очистить таблицу";
            bClear.UseVisualStyleBackColor = true;
            bClear.Click += bClear_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(4, 7);
            label1.Name = "label1";
            label1.Size = new Size(96, 15);
            label1.TabIndex = 4;
            label1.Text = "Производитель";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(4, 34);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 5;
            label2.Text = "Марка";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(4, 61);
            label3.Name = "label3";
            label3.Size = new Size(25, 15);
            label3.TabIndex = 6;
            label3.Text = "ОС";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(4, 88);
            label4.Name = "label4";
            label4.Size = new Size(51, 15);
            label4.TabIndex = 7;
            label4.Text = "Ссылка";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(4, 115);
            label5.Name = "label5";
            label5.Size = new Size(69, 15);
            label5.TabIndex = 8;
            label5.Text = "Стоимость";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 142);
            label6.Name = "label6";
            label6.Size = new Size(71, 15);
            label6.TabIndex = 9;
            label6.Text = "Год релиза";
            // 
            // tbManufacturer
            // 
            tbManufacturer.Location = new Point(106, 4);
            tbManufacturer.Name = "tbManufacturer";
            tbManufacturer.Size = new Size(200, 21);
            tbManufacturer.TabIndex = 10;
            // 
            // tbBrand
            // 
            tbBrand.Location = new Point(106, 31);
            tbBrand.Name = "tbBrand";
            tbBrand.Size = new Size(200, 21);
            tbBrand.TabIndex = 11;
            // 
            // tbOS
            // 
            tbOS.Location = new Point(106, 58);
            tbOS.Name = "tbOS";
            tbOS.Size = new Size(200, 21);
            tbOS.TabIndex = 12;
            // 
            // tbLink
            // 
            tbLink.Location = new Point(106, 85);
            tbLink.Name = "tbLink";
            tbLink.Size = new Size(200, 21);
            tbLink.TabIndex = 13;
            // 
            // tbPrice
            // 
            tbPrice.Location = new Point(106, 112);
            tbPrice.Name = "tbPrice";
            tbPrice.Size = new Size(200, 21);
            tbPrice.TabIndex = 14;
            // 
            // tbYear
            // 
            tbYear.Location = new Point(107, 139);
            tbYear.Name = "tbYear";
            tbYear.Size = new Size(199, 21);
            tbYear.TabIndex = 15;
            // 
            // bAdd
            // 
            bAdd.Location = new Point(3, 176);
            bAdd.Name = "bAdd";
            bAdd.Size = new Size(97, 32);
            bAdd.TabIndex = 16;
            bAdd.Text = "Добавить";
            bAdd.UseVisualStyleBackColor = true;
            bAdd.Click += bAdd_Click;
            // 
            // bEdit
            // 
            bEdit.Location = new Point(106, 176);
            bEdit.Name = "bEdit";
            bEdit.Size = new Size(97, 32);
            bEdit.TabIndex = 17;
            bEdit.Text = "Изменить";
            bEdit.UseVisualStyleBackColor = true;
            bEdit.Click += bEdit_Click;
            // 
            // bDel
            // 
            bDel.Location = new Point(209, 176);
            bDel.Name = "bDel";
            bDel.Size = new Size(97, 32);
            bDel.TabIndex = 18;
            bDel.Text = "Удалить";
            bDel.UseVisualStyleBackColor = true;
            bDel.Click += bDel_Click;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(bSearch);
            panel1.Controls.Add(bDel);
            panel1.Controls.Add(bEdit);
            panel1.Controls.Add(bAdd);
            panel1.Controls.Add(tbYear);
            panel1.Controls.Add(tbPrice);
            panel1.Controls.Add(tbLink);
            panel1.Controls.Add(tbOS);
            panel1.Controls.Add(tbBrand);
            panel1.Controls.Add(tbManufacturer);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.ForeColor = SystemColors.WindowFrame;
            panel1.Location = new Point(8, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(309, 426);
            panel1.TabIndex = 19;
            // 
            // bSearch
            // 
            bSearch.Location = new Point(4, 214);
            bSearch.Name = "bSearch";
            bSearch.Size = new Size(96, 31);
            bSearch.TabIndex = 19;
            bSearch.Text = "Найти";
            bSearch.UseVisualStyleBackColor = true;
            bSearch.Click += bSearch_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Info;
            panel2.Controls.Add(bClear);
            panel2.Controls.Add(bSet);
            panel2.Controls.Add(bDow);
            panel2.ForeColor = SystemColors.MenuHighlight;
            panel2.Location = new Point(320, 440);
            panel2.Name = "panel2";
            panel2.Size = new Size(734, 65);
            panel2.TabIndex = 20;
            // 
            // colManufacturer
            // 
            colManufacturer.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colManufacturer.HeaderText = "Производитель";
            colManufacturer.Name = "colManufacturer";
            // 
            // colBrand
            // 
            colBrand.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colBrand.HeaderText = "Марка";
            colBrand.Name = "colBrand";
            // 
            // colOS
            // 
            colOS.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colOS.HeaderText = "ОС";
            colOS.Name = "colOS";
            // 
            // colLink
            // 
            colLink.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colLink.HeaderText = "Ссылка";
            colLink.Name = "colLink";
            // 
            // colPrice
            // 
            colPrice.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colPrice.HeaderText = "Стоимость";
            colPrice.Name = "colPrice";
            // 
            // colYear
            // 
            colYear.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colYear.HeaderText = "Год релиза";
            colYear.Name = "colYear";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1066, 517);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(dgvAdmin);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "XML BD";
            ((System.ComponentModel.ISupportInitialize)dgvAdmin).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvAdmin;
        private Button bDow;
        private Button bSet;
        private Button bClear;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox tbManufacturer;
        private TextBox tbBrand;
        private TextBox tbOS;
        private TextBox tbLink;
        private TextBox tbPrice;
        private TextBox tbYear;
        private Button bAdd;
        private Button bEdit;
        private Button bDel;
        private Panel panel1;
        private Panel panel2;
        private Button bSearch;
        private DataGridViewTextBoxColumn colManufacturer;
        private DataGridViewTextBoxColumn colBrand;
        private DataGridViewTextBoxColumn colOS;
        private DataGridViewTextBoxColumn colLink;
        private DataGridViewTextBoxColumn colPrice;
        private DataGridViewTextBoxColumn colYear;
    }
}